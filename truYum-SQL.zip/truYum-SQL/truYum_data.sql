create database truYum;
use truYum;

create table Menu_Items(
ID int auto_increment primary key,
Name varchar(20),
Price decimal(8,2),
Active varchar(4),
Date_of_Launch date,
Category varchar(20),
Free_delivery varchar(5)
);
Create table users(
userid int auto_increment primary key,
userName varchar(20)
);
Create table cart(
cartid int auto_increment primary key,
userid int,
ID int,
constraint Fkey1 FOREIGN KEY (userid) REFERENCES users(userid),
constraint Fkey2 foreign key (ID) references menu_items(ID)
);
-- 1. TYUC001
insert into menu_items(Name,Price,Active,Date_of_launch,Category,Free_delivery)
values('Sandwich','99.00','Yes','2017-03-15','Main course','Yes'),
('Burger','129.00','Yes','2017-12-23','Main course','Yes'),
('Pizza','149.00','Yes','2017-08-21','Main course','No'),
('French Fries','57.00','No','2017-07-02','Starters','No'),
('Chocolate Brownie','32.00','Yes','2022-11-02','Dessert','Yes');
 
select Name,concat('Rs. ',Price) as 'Price',
Active,Date_of_Launch,Category,Free_Delivery from menu_items;


-- 2. TYUC002

select Name,concat('Rs. ',Price) as 'Price',
Category,Free_delivery from menu_items
where Active = 'Yes' and Date_of_launch <= curdate();

-- 3. TYUC003
set @ID = 2;
select Name,concat('Rs. ',Price) as 'Price',
Active,Date_of_Launch,Category,Free_Delivery from menu_items where ID = @ID;

update menu_items
set Price='100.00'
where ID= @ID;

-- 4. TYUC004
insert into users(userName)
values('Abhi'),
('Dev');
insert into cart(userid,ID) values(2,4),(2,1),(2,3);

-- 5. TYUC005
set @userid = 2;
 select Name,concat('Rs. ',Price) as 'Price',
 Category,Free_Delivery from menu_items m
 inner join cart c
 on m.ID = c.ID
 INNER JOIN users u
 on u.userid = c.userid
 where u.userid = @userid;
 
 set @userid = 2;
 select sum(Price) as Total_price
 from menu_items m 
 inner join cart c
 on m.ID = c.ID
 inner join users u
 on u.userid = c.userid
 where u.userid = @userid;
 
 -- 6.TYUC006
 set @userid = 2;
 set @ID = 4;
 delete from cart 
where ID = @ID and userid = @userid;
 

 
 
 


